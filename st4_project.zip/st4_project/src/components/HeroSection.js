const HeroSection=({name,image,btnValue})=>{
    return(
        <></>
    )
}
export default HeroSection;