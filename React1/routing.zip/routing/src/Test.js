import React from 'react';

import Test from './components/Test';
import Abcd from  './components/Abcd';

const App= () => {
  return (
    <div>
      <Test/>
      <Test/>
      <Abcd/>  
      <Abcd/>   
     
    </div>
  )
}

export default App;
