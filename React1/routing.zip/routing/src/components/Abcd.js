import React from 'react';

const Abcd = () => {
  return (
    <div>
      <h1>Abcd  Component</h1>
    </div>
  )
}

export default Abcd;
