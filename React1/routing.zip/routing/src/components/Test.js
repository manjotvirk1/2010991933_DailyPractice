import React from 'react';

const Test = () => {
  return (
    <div>
      <h1>This is Test Component</h1>
    </div>
  )
}

export default Test;
